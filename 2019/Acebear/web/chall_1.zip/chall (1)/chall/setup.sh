apt-get update --fix-missing
apt-get -q -y install curl
curl -o xampp-linux-x64-7.3.1-0-installer.run "https://downloadsapachefriends.global.ssl.fastly.net/7.3.1/xampp-linux-x64-7.3.1-0-installer.run?from_af=true"
mv xampp-linux-x64-7.3.1-0-installer.run xampp.run
chmod +x xampp.run
rm -rf /usr/bin/xampp
bash -c './xampp.run --mode unattended' && \
    ln -sf /opt/lampp/xampp /usr/bin/xampp

cp -R ./src/ /opt/lampp/htdocs/wapup/
mkdir /opt/lampp/htdocs/vendor/
curl -o /opt/lampp/htdocs/vendor/ZendFramework-minimal-2.4.13.tgz https://packages.zendframework.com/releases/ZendFramework-2.4.13/ZendFramework-minimal-2.4.13.tgz
cd /opt/lampp/htdocs/vendor/ && tar -xf ZendFramework-minimal-2.4.13.tgz
# no mysql == no sqli
rm -rf "/opt/lampp/phpmyadmin/config.inc.php"
# port 80 we use for another purpose, so this should be 8080
sed -i -- 's/Listen 80/Listen 8080/g' /opt/lampp/etc/httpd.conf
rm -rf /opt/lampp/temp/*
chown root:root -R /opt/lampp/htdocs/wapup/
find /opt/lampp/htdocs/wapup/ -type d -exec chmod 755 {} \;
chmod 1777 /opt/lampp/htdocs/wapup/uploads/
find /opt/lampp/htdocs/wapup/ -type f -exec chmod 644 {} \;


apt-get clean
