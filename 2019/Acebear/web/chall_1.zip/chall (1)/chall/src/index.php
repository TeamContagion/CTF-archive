<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<?php 
error_reporting(0);
require_once 'zf2_autoloader.php';
require_once 'file.php';

function filterSerialized($value) {
    $reg = '/(MrClay)|(Ws)|(Firebase)|(Google)|(GuzzleHttp)|(Monolog)|(phpseclib)|(Psr)|(Juiker)|(libphonenumber)|(Gregwar)|(PhpAmqpLib)|(Twig)|(Symfony)|(PHPUnit)|(mikehaertl)|(Composer)|(Illuminate)|(Carbon)|(Yajra)|(Zalo)|(Acme)|(Doctrine)|(DeepCopy)|(phpDocumentor)|(Prophecy)|(SebastianBergmann)|(Webmozart)|(system)|(passthru)|(exec)|(eval)|(escapeshellcmd)|(popen)|(phar)|(Doctrine)/i';
    $filter = preg_match($reg, urldecode($value), $m);

    if($filter){
      die('Nani??');
    }
}

function getFileType($extension)
{
    $images = array('jpg', 'gif', 'png', 'bmp');
    $docs   = array('txt', 'rtf', 'doc');
    $apps   = array('zip', 'rar', 'exe');
     
    if(in_array($extension, $images)) return "Images";
    if(in_array($extension, $docs)) return "Documents";
    if(in_array($extension, $apps)) return "Applications";
    return "";
}
function formatBytes($bytes, $precision = 2) { 
    $units = array('B', 'KB', 'MB', 'GB', 'TB'); 
    
    $bytes = max($bytes, 0); 
    $pow = floor(($bytes ? log($bytes) : 0) / log(1024)); 
    $pow = min($pow, count($units) - 1); 
    
    $bytes /= pow(1024, $pow); 
    
    return round($bytes, $precision) . ' ' . $units[$pow]; 
} 

function sendCurl($url, $data){
    $ch = curl_init();

    curl_setopt($ch, CURLOPT_URL,            $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1 );
    curl_setopt($ch, CURLOPT_POST,           1 );
    curl_setopt($ch, CURLOPT_POSTFIELDS,     $data); 
    curl_setopt($ch, CURLOPT_HTTPHEADER,     array('Content-Type: text/plain')); 

    $result=curl_exec ($ch);
    return $result;
}
 
$message = "";

if(isset($_FILES['file']) && isset($_POST['keytype']))
{
  
    $uploadpath = "uploads/";

    $target_path = $uploadpath . time() . '_' . basename( $_FILES['file']['name']);

    $keyType = intval($_POST['keytype']);
    $fileType = strtolower(pathinfo($target_path,PATHINFO_EXTENSION));
    $fileSize = $_FILES['file']['size'];


    if(empty($_FILES['file']['tmp_name'])){
        $message = "Hmm, seem like some file is too large!";
    }else
    if($fileType != "jpg" && $fileType != "png" && $fileType != "jpeg"
        && $fileType != "gif" && $fileType != "docx" && $fileType != "doc" && $fileType != "zip") {

          $message =  "Nahhh!";
     
       
    }else  if($fileSize > 10000 ){
            $message = "Too large, we cant handle it!";
    } else{
        if(move_uploaded_file($_FILES['file']['tmp_name'], $target_path)) {
            filterSerialized(file_get_contents($target_path));
            $message = "Sign file <a href='".$target_path. "'>". basename( $_FILES['file']['name']).  "</a> success, here is the result:<br>";
            $signObj = serialize(new SignObject($keyType, $target_path));

            $sig = sendCurl("http://127.0.0.1:8080/wapup/sign/sign.php?action=sign", $signObj);
            $message .= "<textarea>".$sig."</textarea>";

        } else{
            $message = "There was an error uploading the file, please try again!";
        }
    }
 

}

if(strlen($message) > 0)
{
    $message = '<p class="error">' . $message . '</p>';
    echo $message;
}

$uploaded_files = "";
$dh = scandir("uploads/");
if(count($dh)>200){
    foreach($dh as $file){
        if($file != '.' && $file != '..' && $file != '.htaccess')
        {
            unlink('./uploads/'.$file);         
        }
    }
}


?>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
<style type="text/css" media="all"> 
  @import url('style.css');
</style>
<script src="http://code.jquery.com/jquery-latest.js"></script>
<title>Online file storage</title>
</head>
<body>

<div id="container">
    <h1>Online File Storage</h1>
     
    <fieldset>
        <legend>Add a new file to the storage</legend>
        <form method="post" action="index.php" enctype="multipart/form-data">
        <input type="hidden" name="MAX_FILE_SIZE" value="10000" />
       
        <p><label for="name">Select file</label><br />
        <input type="file" name="file" /></p>

        <p><label for="name">Choose a private key</label><br />
        <select name="keytype">
        <option value="1">Private key classic</option>
        <option value="2">Private key VIP</option>
        <option value="3">Private key supreme</option>
        </select></p>


        <p><input type="submit" name="submit" value="Start upload" /></p>
        </form>   
    </fieldset>
    <fieldset>
    <legend>Previousely uploaded files</legend>
    <ul id="menu">
        <li><a href="">All files</a></li>
        <li><a href="">Documents</a></li>
        <li><a href="">Images</a></li>
        <li><a href="">Applications</a></li>
    </ul>
     
    <ul id="files">
   <!-- List file will go here but not now!-->
    </ul>
    </fieldset>

</div>
 
</body>
</html>
