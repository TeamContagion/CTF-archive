<?php

$zf2Path = '/opt/lampp/htdocs/vendor/ZendFramework-2.4.13/library';


if ($zf2Path) {
    $namespaces = array(
        
    );

    include $zf2Path . '/Zend/Loader/AutoloaderFactory.php';
    include $zf2Path . '/Zend/Loader/ClassMapAutoloader.php';
    Zend\Loader\AutoloaderFactory::factory(array(
        'Zend\Loader\StandardAutoloader' => array(
            'autoregister_zf' => true,
            'namespaces' => $namespaces
        ),
    ));
}

if (!class_exists('Zend\Loader\AutoloaderFactory')) {
    throw new RuntimeException('Unable to load ZF2. Run `php composer.phar install` or define a ZF2_PATH environment variable.');
} 
