<?php
require_once 'zf2_autoloader.php';
use Zend\Crypt\PublicKey\Rsa;

class SignObject
{
    private $privKey = null;
    private $signFile = null;
    private $signature = null;
    public function __construct($privKey, $signFile, $signature = null){
        $this->privKey = $privKey;
        $this->signFile = $signFile;
        $this->signature = $signature;
        
    }
    public function sign(){
        $keypath = "./pkey1.pem";
      
        if($this->privKey != null && $this->signFile != null && strstr($this->signFile, 'flag') === false){
            switch($this->privKey){
                case 1:
                  $keypath = "./pkey1.pem";
                break;
                case 2:
                    $keypath = "./pkey2.pem";
                break;
                case 3:
                    $keypath = "./pkey3.pem";
                break;
                default:
                break;
            }

            $rsa = Rsa::factory(array(
                'private_key'   => $keypath,
                'pass_phrase'   => 'test',
                'binary_output' => false
            ));

            $signature = $rsa->sign(file_get_contents($this->signFile), $rsa->getOptions()->getPrivateKey());

            return $signature;
        }
    }

    public function verify(){
        $keypath = "./pkey1.pem";
        if($this->privKey != null && $this->signFile != null && strstr($this->signFile, 'flag') === false){
            switch($this->privKey){
                case 1:
                  $keypath = "./pkey1.pem";
                break;
                case 2:
                    $keypath = "./pkey2.pem";
                break;
                case 3:
                    $keypath = "./pkey3.pem";
                break;
                default:
                break;
            }

            $rsa = Rsa::factory(array(
                'private_key'   => $keypath,
                'pass_phrase'   => 'test',
                'binary_output' => false
            ));

            $confirm = $rsa->verify(file_get_contents($this->signFile), $this->signature,  $rsa->getOptions()->getPublicKey());

            return $confirm;
        }
    }

    public function someMoreFunctionButNotImplementYet(){

    }
}
?>
