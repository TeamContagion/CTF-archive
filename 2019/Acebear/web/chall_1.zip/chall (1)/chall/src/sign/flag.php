<?php
$FLAG = "why do u think this is a flag???";