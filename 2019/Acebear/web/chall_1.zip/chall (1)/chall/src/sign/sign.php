<?php
error_reporting(0);

require_once '../file.php';

function filterSerialized($value) {
    $reg = '/(MrClay)|(Ws)|(Firebase)|(Google)|(GuzzleHttp)|(Monolog)|(phpseclib)|(Psr)|(Juiker)|(libphonenumber)|(Gregwar)|(PhpAmqpLib)|(Twig)|(Symfony)|(PHPUnit)|(mikehaertl)|(Composer)|(Illuminate)|(Carbon)|(Yajra)|(Zalo)|(Acme)|(Doctrine)|(DeepCopy)|(phpDocumentor)|(Prophecy)|(SebastianBergmann)|(Webmozart)|(system)|(passthru)|(exec)|(eval)|(escapeshellcmd)|(popen)|(Doctrine)/i';
    $filter = preg_match($reg, urldecode($value), $m);

    if($filter){
      die('hacker detected');
    }
}

$data = file_get_contents("php://input");
filterSerialized($data);

    switch($_GET['action']){
        case 'sign':
            if(!empty($data)){
                $signObj = unserialize($data);
                echo $signObj->sign();
            }
        break;
        case 'verify':
            if(!empty($data)){
                $signObj = unserialize($data);
                echo $signObj->verify();
            }
        break;
        default:
            echo "Nothing yet";
        break;
    }

